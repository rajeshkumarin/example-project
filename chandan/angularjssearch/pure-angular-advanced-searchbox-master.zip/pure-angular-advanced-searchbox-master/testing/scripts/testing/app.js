'use strict';

angular.module('app', [

  'paasb'

]);
