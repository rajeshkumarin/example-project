'use strict';

module.exports = {

  'server': {

            'options': {

              'port': 9001,

              'base': '<%= paths.testing %>/'

            }

  }

};
