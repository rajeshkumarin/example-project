'use strict';

module.exports = {

  'options': {

    'singleQuotes': true

  },

  'all': {

    'files': {

      '<%= paths.dist %>/<%= paths.scripts %>/ui.core.js': [
        '<%= paths.dist %>/<%= paths.scripts %>/ui.core.js'
      ]

    }

  }

};
