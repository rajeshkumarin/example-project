'use strict';

module.exports = {

  'target': {

    'src': [

      '<%= paths.testing %>/*.html'

    ]

  }

};
