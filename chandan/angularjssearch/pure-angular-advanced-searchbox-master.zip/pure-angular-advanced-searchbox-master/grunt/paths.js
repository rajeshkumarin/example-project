'use strict';

module.exports = {

  'dist' : 'dist',

  'app' : 'src',

  'scripts' : 'scripts',

  'testing': 'testing',

  'templates' : 'views',

  'images' : 'images',

  'styles' : 'styles',

  'config' : 'config'

};
