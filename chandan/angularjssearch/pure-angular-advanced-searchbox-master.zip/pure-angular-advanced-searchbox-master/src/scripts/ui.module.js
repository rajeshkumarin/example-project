'use strict';

angular.module('paasb', [

  'paasb.config'

]);
